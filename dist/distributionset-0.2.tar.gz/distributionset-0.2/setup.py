from setuptools import setup

setup(name='distributionset',
      version='0.2',
      description='Gaussian and Binomial distributions',
      packages=['distributionset'],
      author='Dennis Bader',
      author_email='dennis.bader@gmx.ch',
      zip_safe=False)
